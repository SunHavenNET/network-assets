Small Caps Digits – Minecraft Java 1.21.11

This pack does NOT replace the normal digits 0-9.

It adds ten custom glyphs to minecraft:default using the Private Use Area:
0 -> U+E000
1 -> U+E001
...
9 -> U+E009

Copy characters:
0 = U+E000 = 
1 = U+E001 = 
2 = U+E002 = 
3 = U+E003 = 
4 = U+E004 = 
5 = U+E005 = 
6 = U+E006 = 
7 = U+E007 = 
8 = U+E008 = 
9 = U+E009 = 

All ten in order:


Example idea:
Use the special characters only in text/components/prefixes/display names where you want the small-cap-height numbers.
Normal '0123456789' continue to render exactly as vanilla.

Note:
The special characters only look like digits while this resource pack is active.
