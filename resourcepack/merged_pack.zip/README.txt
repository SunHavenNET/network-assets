Raid Items Pack für Minecraft Java 1.21.11

Installation:
1. RaidItems_Datapack.zip in saves/<Welt>/datapacks legen.
2. RaidItems_Resourcepack.zip in resourcepacks legen und aktivieren.
3. /reload ausführen.

Give-Commands:
/function raiditems:give_sulfurpowder
/function raiditems:give_charcoalpowder
/function raiditems:give_burlap_sack
/function raiditems:give_handheld_transceiver
/function raiditems:give_gunpowder_custom
/function raiditems:give_explosive
/function raiditems:give_homemade_breaching_charge
/function raiditems:give_homemade_c4
/function raiditems:give_heavy_c4

Rezepte:
- 1 Glowstone Dust + 1 Black Dye -> Custom Gunpowder
- 5 Gunpowder + 1 Rabbit Hide -> Explosive
- 1 Firework Star + 1 Echo Shard -> Homemade Breaching Charge
- 1 TNT + 1 Redstone -> Homemade C4

Wichtig:
Vanilla-Crafting kann in normalen Rezepten Custom-Components bei Zutaten nicht zuverlässig erzwingen.
Deshalb nehmen die Rezepte Base-Items als Input, geben aber Custom-Items aus.
Für strikte Prüfung deiner Custom-Zutaten sollte dein Plugin die Crafting-Events prüfen.
Heavy C4 hat keinen Crafting-Recipe und kann von deinem Plugin vergeben werden.
