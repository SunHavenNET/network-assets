# SunHaven-Network

**sunhaven.net** · Minecraft Java **26.3** · resource-pack format **97.1**.

Seven custom items in the explosives collection, including plugin-controlled C4
states and countdown displays. Existing `sunhaven:` appearance identifiers remain
stable. The pack has no custom equipment, core shaders or vanilla overrides.

## Install

Enable **SunHaven-Network.zip** in the client's resource-pack list. Its root contains
`pack.mcmeta`; `pack/` is the unpacked runtime folder. Use the same ZIP for server
resource-pack delivery. `checksums.json` provides SHA-1 and SHA-256 for the final
runtime and authoring archives.

## Items

| Item | `minecraft:item_model` |
| --- | --- |
| Standard C4 | `sunhaven:standard_c4` |
| Heavy C4 | `sunhaven:heavy_c4` |
| Explosive Compound | `sunhaven:explosive_compound` |
| Electronic Circuit | `sunhaven:electronic_circuit` |
| Detonator | `sunhaven:detonator` |
| Explosive Cartridge | `sunhaven:explosive_cartridge` |
| Reinforced Casing | `sunhaven:reinforced_casing` |

These are appearance IDs, not newly registered material types. The complete
contract is in `source/item-catalog.json`. Matching English/German item names and
named obtain commands are supplied in the language files and `give-commands.txt`.

```mcfunction
/give @s minecraft:paper[minecraft:item_model="sunhaven:standard_c4"] 1
```

[C4-STATES.md](C4-STATES.md) documents `idle`, `armed`, `active`, `defused`, `spent`
and the 30-to-0 display. Set `minecraft:custom_model_data.strings[0]` to the state
and `floats[0]` to whole remaining seconds. The server controls each charge's
actual timer and explosion; texture flipbooks only provide cosmetic signals.
The pack supplies no recipes, placement, damage logic or server item identity.

## Sources and previews

**SunHaven-Network-authoring.zip** contains the runtime pack, eleven editable
`.pcraft` documents, the two existing C4 `.bbmodel` sources, drawing plans/jobs,
validation tools and software previews. No reference-pack assets are included.

- `source/c4_states.pcraft`: editable shared state-display master.
- `source/c4-state-catalog.json`: state, seconds and texture-slice contract.
- `previews/collection.png`: all seven items.
- `previews/c4-states.png`, `c4-countdown.gif`: state/countdown examples.
- `previews/*-views.png`: geometry and authored display-transform inspections.

## Reproduce and verify

```sh
python3 tools/roundtrip.py
python3 tools/validate.py
python3 tools/check_c4_states.py
python3 tools/check_minecraft_parser.py
python3 tools/package.py
```

For asset edits use `build_assets.py`, `paint.py`, `export_blockbench.py` and
`render.py`; `c4_states.py --paint` rebuilds the C4 master through PhotoCraft.
The base generator preserves the expanded C4 definitions when that master exists.
`network_brand.py` builds the independent network icon.

Python tools use Pillow/NumPy. Native painting/reopen uses PhotoCraft CLI/MCP.
The codec check compiles with installed Java 25 and loads the actual installed
Minecraft 26.3 client classes without opening a game. Helper paths are explicit.

See [QA.md](QA.md) for executed checks and limits. Software previews and codec
checks do not replace a live client test. No plugin, website or live server pack
was changed.
