# C4-Zustände und Plugin-Anbindung

Für **Minecraft Java 26.3 / Packformat 97.1**. Beide bisherigen IDs bleiben gleich:
`sunhaven:standard_c4` und `sunhaven:heavy_c4`.

| Zustand | Darstellung | Zweck |
| --- | --- | --- |
| `idle` | Bisheriges mintfarbenes/bernsteinfarbenes Display mit ruhigem Statuslauf | Im Inventar, noch nicht scharf |
| `armed` | Gelbes `--`, blinkende Bereitschafts-LED | Platziert/scharf, wartet auf Aktivierung |
| `active` | Rote Zahl `30` bis `00`, schrumpfender Zeitbalken | Laufender Zünder |
| `defused` | Grünes `OK` mit Status-LED | Entschärft; Zünder abgebrochen |
| `spent` | Dunkles `XX`, erloschene LED | Optionaler verbrauchter Zustand |

Bei `active` blinken LED/Balken normalerweise im 20-Tick-Zyklus. Bei **5 bis 0 Sekunden**
kommt eine seitliche rote Warnleiste hinzu; der Blinkzyklus verkürzt sich auf 6 Ticks.
Die Zahl bleibt in beiden Blinkphasen lesbar. `spent` verändert nur das Display, nicht
die Geometrie des Gehäuses. Es ist kein zerstörtes Modell und kein Explosionseffekt.

## Komponentenvertrag

Der gleiche Item-Model-Identifier funktioniert für alle Zustände. Zusätzlich setzen:

```snbt
minecraft:custom_model_data={strings:["active"],floats:[30.0f]}
```

- `strings[0]`: `idle`, `armed`, `active`, `defused` oder `spent`, exakt kleingeschrieben.
- `floats[0]`: verbleibende **ganze** Sekunden, `0` bis `30`; nur bei `active` ausgewertet.
- Fehlender/unbekannter Zustand: bisherige `idle`-Darstellung.
- Bei `active` ohne Restzeit oder mit negativem Wert erscheint `00`; oberhalb 30 erscheint `30`.
- Bruchwerte werden durch die Modellschwellen abgerundet: `5.9` zeigt `05`.
  Das Plugin soll selbst endliche ganze Werte im Bereich 0–30 validieren und setzen.
- Index 0 beider Listen ist für C4 reserviert. Zusätzliche Einträge in den Komponenten
  bei Aktualisierungen erhalten, wenn andere Systeme sie verwenden.

Die Auswahl nutzt Vanilla `minecraft:select` und `minecraft:range_dispatch`. Es gibt
34 gemeinsam genutzte kleine Bildschirmtexturen und je C4 34 Modelle, die das bisherige
Grundmodell erben und ausschließlich dessen `screen`-Textur austauschen. Geometrie,
UVs und alle Hand-/GUI-Transforms bleiben erhalten. Keine zusätzliche Client-Mod nötig.

## Testbefehle

```mcfunction
/give @s minecraft:paper[minecraft:item_model="sunhaven:standard_c4",minecraft:custom_model_data={strings:["armed"]}] 1
/give @s minecraft:paper[minecraft:item_model="sunhaven:standard_c4",minecraft:custom_model_data={strings:["active"],floats:[30.0f]}] 1
/give @s minecraft:paper[minecraft:item_model="sunhaven:heavy_c4",minecraft:custom_model_data={strings:["active"],floats:[5.0f]}] 1
/give @s minecraft:paper[minecraft:item_model="sunhaven:heavy_c4",minecraft:custom_model_data={strings:["active"],floats:[0.0f]}] 1
/give @s minecraft:paper[minecraft:item_model="sunhaven:standard_c4",minecraft:custom_model_data={strings:["defused"]}] 1
/give @s minecraft:paper[minecraft:item_model="sunhaven:heavy_c4",minecraft:custom_model_data={strings:["spent"]}] 1
```

Diese Befehle erzeugen **Darstellungsbeispiele**. Ein Item mit `active` und `30` bleibt
auf `30`, bis der Server einen anderen Wert setzt. Es explodiert nicht von allein.
Alle fünf Zustände und beide Itemtypen stehen auch in `give-commands.txt`.

## Ablauf für das spätere Plugin

1. Plugin-eigene Itemidentität und Berechtigung prüfen; Modell/CustomModelData sind nur Darstellung.
2. Beim Platzieren eine eigene Ladung mit ID und einem ItemDisplay anlegen. Dessen
   ItemStack trägt den passenden `item_model` und zunächst `armed`.
3. Bei Aktivierung die Ladung genau einmal starten, Ablaufzeit festhalten und `active` + `30` setzen.
4. Restzeit aus der eigenen Ablaufzeit berechnen, aufrunden und auf 0–30 begrenzen.
   Nur bei einer Änderung den ItemStack des Displays aktualisieren. Bei zwei Ladungen
   können gleichzeitig beispielsweise `27` und `12` angezeigt werden.
5. Bei Ablauf serverseitig genau einmal die Spiellogik für die Explosion ausführen
   und das Display entfernen. `active` + `0` steht als Darstellung zur Verfügung;
   eine sichtbare Null ist bei sofortigem Entfernen wegen Client-/Netzwerk-Timing
   nicht garantiert. Falls sie sichtbar bleiben soll, diese Abschlussphase bewusst
   in den Plugin-Ablauf aufnehmen.
6. Beim Entschärfen erst den Zünder ungültig machen/abbrechen, dann `defused` setzen.
   Späte Timer-Callbacks dürfen keine Explosion mehr auslösen. `spent` ist optional.

Bei Canvas müssen Entity-/Region-Besitz und die passenden Scheduler eingehalten werden.
Keine blockierenden Warteschleifen; Timer, Entschärfung und Explosion gehören in eine
serverseitige Zustandsmaschine. Ob 30 Sekunden echte Zeit oder 600 Serverticks bedeuten,
legt das Plugin fest. Bei echter Zeit nach einer Deadline rechnen, nicht Callback-Aufrufe zählen.
Das Resourcepack enthält weder Scheduler noch Sounds, Explosionsschaden, Platzierungslogik
oder serverseitige Identitätsprüfung. An keinem Plugin wurde hier etwas geändert.

## Quellen und Vorschauen

- `source/c4_states.pcraft`: editierbarer PhotoCraft-Master mit Ebenen für Glas, Ziffern und Signale.
- `source/c4-states-plan.json`: exakter Pixelplan; `source/c4_states.png`: unveränderter Editor-Export.
- `source/c4-state-catalog.json`: Komponenten und Schnittkoordinaten aller Runtime-Texturen.
- Die bestehenden beiden `.bbmodel`-Dateien bleiben die Quelle der gemeinsamen Geometrie
  und zeigen den Idle-Zustand. Die geerbten Runtime-JSONs tauschen nur die Displaytextur aus.
- `previews/c4-states.png`: beide C4s in sieben repräsentativen Zuständen.
- `previews/c4-countdown-screens.png`: alle 31 Zahlen.
- `previews/c4-countdown.gif`: Software-Beispiel mit nacheinander gesetzten Restzeiten;
  die GIF-Schleife ist kein Verhalten des Resourcepacks.
- `previews/*-active-views.png`: GUI, Front, Rückseite, beide Hände und Bodentransform.

Neu bauen: `python3 tools/c4_states.py --paint`, danach
`python3 tools/preview_c4_states.py`, `python3 tools/validate.py`,
`python3 tools/check_c4_states.py`, `python3 tools/check_minecraft_parser.py`
und `python3 tools/package.py`. Ohne `--paint` werden vorhandene Master-Pixel neu geschnitten.
Ein vollständiger Basis-Rebuild erhält die erweiterten Itemdefinitionen; Änderungen am
Master müssen vor dem Export erneut durch PhotoCraft laufen.

Die Item-Model-Technik ist in [Mojangs Beschreibung des Item-Modellsystems](https://www.minecraft.net/en-us/article/minecraft-snapshot-24w45a)
dokumentiert. Die fertigen JSONs wurden zusätzlich durch den lokal installierten 26.3-Parser
geprüft. Softwarevorschau und Codec-Prüfung ersetzen keinen Test im laufenden Minecraft-Client.
